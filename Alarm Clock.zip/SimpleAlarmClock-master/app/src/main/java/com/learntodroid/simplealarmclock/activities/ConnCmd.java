package com.learntodroid.simplealarmclock.activities;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

public class ConnCmd {

    public  static    String res;
    public  static    String ip="http://192.168.43.206";
  public  static String getip()
    {
        return ip;
    }
    public static void setip(String Nip)
    {
        ip=Nip;
    }

    public static String  Cmd(String ip,String url)
    {
        String Curl=ip+"/"+url;
        StringRequest stringRequest = new StringRequest (Request.Method.POST,url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response)
                    {

                    }
                }, new Response.ErrorListener()
        {
            @Override
            public void onErrorResponse(VolleyError error)
            {
                res="Not Network";
                error.printStackTrace();
            }
        });
       return res;
    }
}
